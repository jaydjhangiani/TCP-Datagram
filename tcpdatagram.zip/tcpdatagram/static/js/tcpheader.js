let flag = 0 ,msg;
function ipDatagram(){
    let hex = document.getElementById('hexInput').value;
    let spa = convert(hex.slice(0,4));
    let dpa = convert(hex.slice(4,8));
    let seq = convert(hex.slice(8,16));
    //checkServiceType(st);
    let ack = convert(hex.slice(16,24));
    let hlen = convert(hex.slice(24,25))*4 +' Bytes';
    let dummy = (hex.slice(25,28));
    //console.log(dummy);
    to_binary(dummy);
    let ws = convert(hex.slice(28,32))+' Bytes';
    let cs = convert(hex.slice(32,36))+' Bytes';
    let up = convert(hex.slice(36,40));
    console.log(hex);
    console.log(spa,dpa,seq,ack,hlen,dummy,msg,ws,cs,up);
    document.querySelector('#SPA').textContent = spa;
    document.querySelector('#DPA').textContent = dpa;
    document.querySelector('#SEQ').textContent = seq;
    document.querySelector('#ACK').textContent = ack;
    document.querySelector('#HLEN').textContent = hlen;
    document.querySelector('#RES').textContent = 'X';
    document.querySelector('#FLAG').textContent = msg;
    document.querySelector('#WS').textContent = ws;
    document.querySelector('#CS').textContent = cs;
    document.querySelector('#UP').textContent = up;

}
function convert(hex){
    
    decimal_number = Number(hexToDec(hex));
    return decimal_number;
}

function hexToDec(s) {
    var i, j, digits = [0], carry;
    for (i = 0; i < s.length; i += 1) {
        carry = parseInt(s.charAt(i), 16);
        for (j = 0; j < digits.length; j += 1) {
            digits[j] = digits[j] * 16 + carry;
            carry = digits[j] / 10 | 0;
            digits[j] %= 10;
        }
        while (carry > 0) {
            digits.push(carry % 10);
            carry = carry / 10 | 0;
        }
    }
    return digits.reverse().join('');
}

function to_binary(num){
    let b1 = Number(num.slice(0,1));
    let b2 = Number(num.slice(1,2));
    let b3 = Number(num.slice(2,3));
    bn0 = b1.toString(2);
    bn1 = b2.toString(2);
    bn2 = b3.toString(2);
    bn0 = bn0.padStart(4,'0');
    bn1 = bn1.padStart(4,'0');
    bn2 = bn2.padStart(4,'0');
    bnum = bn0+bn1+bn2;
    let flag = bnum.slice(6,12);
    checkFlag(flag);
    console.log(bnum,flag);
}

function checkFlag(flag){
    f1 = flag.slice(0,1);
    f2 = flag.slice(1,2);
    f3 = flag.slice(2,3);
    f4 = flag.slice(3,4);
    f5 = flag.slice(4,5);
    f6 = flag.slice(5,6);

    if (f1 === '1'){
        msg = 'URG'
    }
    else if (f2 === '1'){
        msg = 'ACK'
    }
    else if (f3 === '1'){
        msg = 'PSH'
    }
    else if (f4 === '1'){
        msg = 'RST'
    }
    else if (f5 === '1'){
        msg = 'SYN'
    }
    else if (f6 === '1'){
        msg = 'FIN'
    }
}

//053200170000000100000000500207FF00000000